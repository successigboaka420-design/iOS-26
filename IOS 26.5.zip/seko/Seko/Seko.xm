#import <UIKit/UIKit.h>
#import "SekoGlass.h"

static BOOL SekoEnabled = YES;

static BOOL SekoLoadEnabled(void)
{
    NSDictionary *prefs =
        [NSDictionary dictionaryWithContentsOfFile:
            @"/var/mobile/Library/Preferences/com.seko.tweak.plist"];

    if (!prefs || !prefs[@"Enabled"])
        return YES;

    return [prefs[@"Enabled"] boolValue];
}

%hook SpringBoard

- (void)applicationDidFinishLaunching:(UIApplication *)application
{
    %orig;

    SekoEnabled = SekoLoadEnabled();

    if (SekoEnabled)
    {
        NSLog(@"[SEKO] Seko 1.0.0 loaded");
        NSLog(@"[SEKO] iOS 26 Experience enabled");
    }
}

%end


%hook UINavigationBar

- (void)didMoveToWindow
{
    %orig;

    if (!SekoEnabled)
        return;

    if (@available(iOS 13.0, *))
    {
        UINavigationBarAppearance *appearance =
            [[UINavigationBarAppearance alloc] init];

        appearance.backgroundEffect =
            [UIBlurEffect effectWithStyle:
                UIBlurEffectStyleSystemChromeMaterial];

        appearance.backgroundColor =
            [UIColor colorWithWhite:1.0 alpha:0.035];

        appearance.shadowColor =
            [UIColor clearColor];

        self.standardAppearance = appearance;
        self.scrollEdgeAppearance = appearance;

        if (@available(iOS 15.0, *))
            self.compactAppearance = appearance;
    }
}

%end